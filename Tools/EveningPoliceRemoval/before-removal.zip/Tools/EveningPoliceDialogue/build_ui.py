"""Author editable police dialogue below SeatingCanvas using Lawyer Room templates."""
from pathlib import Path
import re, json, uuid
ROOT=Path(__file__).resolve().parents[2]
SCENE=ROOT/'Assets/MainScenes/From_PM/MainScene_2_Evening.unity'
s=SCENE.read_text(encoding='utf-8-sig')
lawyer=(ROOT/'Assets/MainScenes/From_PM/Lawyer Room.unity').read_text(encoding='utf-8-sig')
def parse(text):
    return {int(m[2]):m.group() for m in re.finditer(r'^--- !u!(\d+) &(-?\d+)[^\n]*\n.*?(?=^---|\Z)',text,re.M|re.S)}
original=parse(lawyer); scene=parse(s)
assert 'm_Name: PoliceEncounter\n' not in s
(Path(__file__).parent/'before-dialogue.unity.txt').write_text(s,encoding='utf-8')
next_id=732000001
output=[]
def alloc():
    global next_id
    result=next_id; next_id+=1
    assert result not in scene
    return result
def owner(block): return int(re.search(r'  m_GameObject: \{fileID: (-?\d+)',block)[1])
def component(go,kind,docs=original):
    return next(i for i,b in docs.items() if b.startswith('--- !u!'+str(kind)+' ') and f'  m_GameObject: {{fileID: {go}}}\n' in b)
def subtree(go):
    found=[go]
    components=[int(i) for i in re.findall(r'  - component: \{fileID: (-?\d+)',original[go])]
    found+=components
    rect=next(i for i in components if original[i].startswith(('--- !u!224 ','--- !u!4 ')))
    children=re.search(r'  m_Children:(.*?)(?=  m_Father:)',original[rect],re.S)[1]
    for child in re.findall(r'fileID: (-?\d+)',children): found+=subtree(owner(original[int(child)]))
    return found
def clone(go,name,parent):
    mapping={i:alloc() for i in subtree(go)}
    rect=component(go,224)
    for id,new in mapping.items():
        b=original[id]
        if id==go:
            b=re.sub(r'^  m_Name: .*','  m_Name: '+name,b,flags=re.M)
            b=re.sub(r'^  m_IsActive: .*','  m_IsActive: 0',b,flags=re.M)
        if id==rect: b=re.sub(r'  m_Father: .*',f'  m_Father: {{fileID: {parent}}}',b)
        b=re.sub(r'&(-?\d+)',lambda m:'&'+str(mapping.get(int(m[1]),int(m[1]))),b)
        b=re.sub(r'fileID: (-?\d+)',lambda m:'fileID: '+str(mapping.get(int(m[1]),int(m[1]))),b)
        # Strip persistent UnityEvents so cloned choices cannot call Lawyer Room objects.
        b=re.sub(r'(    m_PersistentCalls:\n)      m_Calls:\n(?:      - .*\n|        .*\n)+',r'\1      m_Calls: []\n',b)
        output.append((new,b))
    return mapping[go],mapping[rect],mapping
def edit(id,fn):
    for k,(key,b) in enumerate(output):
        if key==id: output[k]=(key,fn(b)); return
    raise KeyError(id)
def text(id,value,white=False):
    def change(b):
        b=re.sub(r'^  m_text: .*',lambda m:'  m_text: '+json.dumps(value,ensure_ascii=True),b,flags=re.M)
        if white:
            b=re.sub(r'^  (m_Color|m_fontColor): .*',lambda m:'  '+m[1]+': {r: 1, g: 1, b: 1, a: 1}',b,flags=re.M)
            b=re.sub(r'    rgba: \d+','    rgba: 4294967295',b)
        return b
    edit(id,change)
def mono(guid): return next(b for b in original.values() if f'guid: {guid},' in b)
aunt=mono('316a0c03626e4657a4e5d66483429289')
choices=mono('347d7d2282b04577ba641e87433c971d')
def ref(b,name): return int(re.search(r'  '+name+r': \{fileID: (-?\d+)',b)[1])
canvas_go=next(i for i,b in scene.items() if '  m_Name: SeatingCanvas\n' in b)
canvas_rect=component(canvas_go,224,scene)
group,rect,controller,canvas,raycaster=[alloc() for _ in range(5)]
children=[]
views={}
for source,name,speaker in [('visitorDialogue','PoliceDialogue','ตำรวจเลว'),('khemDialogue','KhemDialogue','เข้ม'),('thoughtDialogue','ActionDescription','')]:
    data=re.search(r'  '+source+r':\n(.*?)(?=^  \w|\Z)',aunt,re.S|re.M)[1]
    refs={field:int(re.search(r'    '+field+r': \{fileID: (-?\d+)',data)[1]) for field in ('canvas','motionRoot','speaker','sentence')}
    go=owner(original[refs['canvas']])
    newgo,newrect,mapping=clone(go,name,rect); children.append(newrect)
    views[name]={key:mapping[id] for key,id in refs.items()}
    text(mapping[refs['speaker']],speaker,True)
    text(mapping[refs['sentence']],'',True)
    colour=(.25,.7,1) if source=='khemDialogue' else (.6754716,.22292897,.15166242)
    edit(mapping[refs['speaker']],lambda b,c=colour:re.sub(r'^  (m_Color|m_fontColor): .*',lambda m:'  '+m[1]+': {r: %s, g: %s, b: %s, a: 1}'%c,b,flags=re.M))
    edit(mapping[refs['canvas']],lambda b:re.sub(r'm_SortingOrder: \d+','m_SortingOrder: 32490',b).replace('m_OverrideSorting: 0','m_OverrideSorting: 1'))

line_source=ref(aunt,'firstLine')
line_go=owner(original[line_source]); line_rect=component(line_go,224)
line_panel=int(re.search(r'm_Father: \{fileID: (\d+)',original[line_rect])[1]); line_panel_go=owner(original[line_panel])
lines={}
sentences={
 'introduction':'ขอโทษนะครับ พื้นที่นี้อนุญาตให้เข้าแค่เจ้าหน้าที่นะครับ',
 'lieReply':'<color=#FF3333>(โกหก)</color> พอดีผมได้รับอนุญาตจากตำรวจที่สถานีมาแล้วน่ะครับ เพราะฉะนั้นขอเข้าไปดูหน่อยนะครับ',
 'lawyerReply':'ผมเป็นทนายของฝั่งเหยื่อในคดีนี้ พอดีเห็นว่ายังเพิ่งเกิดเหตุได้ไม่นาน เลยอยากจะมาดูด้วยตาตนเองหน่อยน่ะครับ',
 'radioReaction':'(ตำรวจวิทยุกลับไปที่สถานี เพื่อตรวจสอบว่าเข้มได้รับอนุญาตมาจริงหรือไม่)',
 'refusedReaction':'ยังไงก็ไม่อนุญาตครับ คุณเห็นมั้ยว่าเจ้าหน้าที่ทำงานกันอยู่ กรุณาถอยออกไปและอย่ารบกวนการทำงานของเจ้าหน้าที่ด้วยครับ',
 'sunglassesReply':'แล้วนั่นเจ้าหน้าที่ด้วยมั้ยครับ',
 'evidenceReply':'ขอโทษที่รบกวนครับ แต่ผมมีสิทธิ์เก็บหลักฐานในที่เกิดเหตุเพื่อปกป้องสิทธิ์ของลูกความผม',
 'threatReaction':'(ตำรวจไม่พูดอะไร เอามือหนึ่งจับปืน และอีกมือดันตัวเข้มให้ถอยออกไป)',
 'finalPoliceReply':'แต่ตามกฎหมายคุณไม่มีสิทธิ์บังคับให้ผมเปิดพื้นที่ให้คุณตามอำเภอใจ ถ้าอยากได้สิทธิ์เข้าถึงพื้นที่ ไปคุยกับหัวหน้าผมที่สถานี ระหว่างนี้กรุณาถอยไปครับ'}
lines_go,lines_rect=alloc(),alloc()
line_children=[]
for name,value in sentences.items():
    go,r,mapping=clone(line_panel_go,name,lines_rect); line_children.append(r)
    lines[name]=mapping[line_source]; text(lines[name],value,True)

choicego,choicerect,cm=clone(owner(choices),'ReplyChoices',rect); children.append(choicerect)
choicecomp=cm[int(re.search(r'&(-?\d+)',choices)[1])]
edit(choicecomp,lambda b:b.replace('normalTextColor: {r: 0.96, g: 0.96, b: 0.96, a: 1}','normalTextColor: {r: 1, g: 1, b: 1, a: 1}'))
edit(choicerect,lambda b:re.sub(r'  m_SizeDelta: .*','  m_SizeDelta: {x: 1500, y: 360}',b))
for field,y,initial in [('acceptButton',90,sentences['lieReply']),('refuseButton',-90,sentences['lawyerReply'])]:
    button_id=ref(choices,field); button_go=owner(original[button_id]); button_rect=component(button_go,224)
    edit(cm[button_rect],lambda b,y=y:re.sub(r'  m_SizeDelta: .*','  m_SizeDelta: {x: 1500, y: 160}',re.sub(r'  m_AnchoredPosition: .*',f'  m_AnchoredPosition: {{x: 0, y: {y}}}',b)))
    label=ref(choices,'acceptLabel' if field=='acceptButton' else 'refuseLabel')
    text(cm[label],initial,True)
    edit(cm[label],lambda b:re.sub(r'  m_fontSize(Base)?: .*',lambda m:'  m_fontSize'+(m[1] or '')+': 30',b))

objective_source=int(re.search(r'  exitObjectiveText: \{fileID: (\d+)',lawyer)[1])
objgo=owner(original[objective_source]); objrect=component(objgo,224)
objparent=owner(original[int(re.search(r'm_Father: \{fileID: (\d+)',original[objrect])[1])])
objective={}
for name,words,anchor in [('returnObjective','กลับไปที่รถ',.16),('enterCarPrompt','[F] ขึ้นรถ',.16)]:
    go,r,mapping=clone(objparent,name,rect); children.append(r)
    objective[name]=mapping[objective_source]; text(objective[name],words,name=='enterCarPrompt')
    edit(r,lambda b,anchor=anchor:re.sub(r'  m_Anchor(Min|Max): .*',lambda m:'  m_Anchor'+m[1]+f': {{x: 0.5, y: {anchor}}}',re.sub(r'  m_AnchoredPosition: .*','  m_AnchoredPosition: {x: 0, y: 0}',b)))
    if name=='returnObjective': edit(r,lambda b:b.replace('m_AnchoredPosition: {x: 0, y: 0}','m_AnchoredPosition: {x: 0, y: -100}'))

# Use the same typing clip and authored source volume as the aunt's dialogue.
audio_old=int(re.search(r'    typingAudio: \{fileID: (\d+)',aunt)[1]); audio=alloc()
ab=original[audio_old]
ab=re.sub(r'^--- !u!82 &\d+',f'--- !u!82 &{audio}',ab,flags=re.M)
ab=re.sub(r'm_GameObject: \{fileID: \d+\}',f'm_GameObject: {{fileID: {group}}}',ab)
output.append((audio,ab))
def simple_group(go,r,name,parent,kids,extra=''):
    comps=f'  - component: {{fileID: {r}}}\n'+extra
    return f'''--- !u!1 &{go}
GameObject:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  serializedVersion: 6
  m_Component:
{comps}  m_Layer: 5
  m_Name: {name}
  m_TagString: Untagged
  m_Icon: {{fileID: 0}}
  m_NavMeshLayer: 0
  m_StaticEditorFlags: 0
  m_IsActive: 1
--- !u!224 &{r}
RectTransform:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_GameObject: {{fileID: {go}}}
  m_LocalRotation: {{x: 0, y: 0, z: 0, w: 1}}
  m_LocalPosition: {{x: 0, y: 0, z: 0}}
  m_LocalScale: {{x: 1, y: 1, z: 1}}
  m_ConstrainProportionsScale: 0
  m_Children:
'''+''.join(f'  - {{fileID: {kid}}}\n' for kid in kids)+f'''  m_Father: {{fileID: {parent}}}
  m_LocalEulerAnglesHint: {{x: 0, y: 0, z: 0}}
  m_AnchorMin: {{x: 0, y: 0}}
  m_AnchorMax: {{x: 1, y: 1}}
  m_AnchoredPosition: {{x: 0, y: 0}}
  m_SizeDelta: {{x: 0, y: 0}}
  m_Pivot: {{x: 0.5, y: 0.5}}
'''
children.append(lines_rect)
group_blocks=simple_group(group,rect,'PoliceEncounter',canvas_rect,children,''.join(f'  - component: {{fileID: {id}}}\n' for id in (controller,canvas,raycaster,audio)))
group_blocks+=simple_group(lines_go,lines_rect,'Lines',rect,line_children)
# Saved nested canvas and raycaster, never a runtime root Canvas.
canvas_template=next(b for b in scene.values() if b.startswith('--- !u!223 ') and 'm_SortingOrder: 32000' in b)
cb=re.sub(r'^--- !u!223 &\d+',f'--- !u!223 &{canvas}',canvas_template,flags=re.M)
cb=re.sub(r'm_GameObject: \{fileID: \d+\}',f'm_GameObject: {{fileID: {group}}}',cb).replace('m_SortingOrder: 32000','m_SortingOrder: 32500')
group_blocks+=cb
ray=next(b for b in scene.values() if 'UnityEngine.UI.GraphicRaycaster' in b)
ray=re.sub(r'^--- !u!114 &\d+',f'--- !u!114 &{raycaster}',ray,flags=re.M)
ray=re.sub(r'm_GameObject: \{fileID: \d+\}',f'm_GameObject: {{fileID: {group}}}',ray)
group_blocks+=ray
for name in ['EveningPoliceDialogue','PorschePassengerRide.Boarding']:
    p=ROOT/f'Assets/SecretsThatBreathe/Scripts/{name}.cs.meta'
    if not p.exists(): p.write_text('fileFormatVersion: 2\nguid: '+uuid.uuid4().hex+'\nMonoImporter:\n  externalObjects: {}\n  serializedVersion: 2\n  defaultReferences: []\n  executionOrder: 0\n  icon: {instanceID: 0}\n  userData:\n  assetBundleName:\n  assetBundleVariant:\n')
guid=re.search(r'guid: (\w+)',(ROOT/'Assets/SecretsThatBreathe/Scripts/EveningPoliceDialogue.cs.meta').read_text())[1]
comp=f'''--- !u!114 &{controller}
MonoBehaviour:
  m_ObjectHideFlags: 0
  m_CorrespondingSourceObject: {{fileID: 0}}
  m_PrefabInstance: {{fileID: 0}}
  m_PrefabAsset: {{fileID: 0}}
  m_GameObject: {{fileID: {group}}}
  m_Enabled: 1
  m_EditorHideFlags: 0
  m_Script: {{fileID: 11500000, guid: {guid}, type: 3}}
  m_Name:
  m_EditorClassIdentifier: Assembly-CSharp::SecretsThatBreathe.EveningPoliceDialogue
'''
for field,name in [('police','PoliceDialogue'),('khem','KhemDialogue'),('action','ActionDescription')]:
    comp+='  '+field+':\n'+''.join(f'    {key}: {{fileID: {id}}}\n' for key,id in views[name].items())+'    normalizeFontBaseline: 1\n    layoutRevision: 2\n'
comp+='  presentation:\n    secondsPerCharacter: 0.05\n    completedLineHold: 1\n    scrollSpeed: 18\n'+f'    typingAudio: {{fileID: {audio}}}\n'
comp+=f'  choices: {{fileID: {choicecomp}}}\n'
comp+='  narrationHoldSeconds: 3\n  finalReactionHoldSeconds: 3\n'
comp+='  dialogueStyleRevision: 4\n'
for key,id in {**lines,**objective}.items(): comp+=f'  {key}: {{fileID: {id}}}\n'
comp+='  boardingDistance: 2\n  sunglassesMan: {fileID: 0}\n'
root_rect=scene[canvas_rect]
s=s.replace(root_rect,root_rect.replace('  m_Children:\n',f'  m_Children:\n  - {{fileID: {rect}}}\n'))
s=s.replace('--- !u!1660057539',group_blocks+comp+''.join(b for _,b in output)+'--- !u!1660057539')
ids=re.findall(r'^--- !u!\d+ &(-?\d+)',s,re.M); assert len(ids)==len(set(ids))
SCENE.write_text(s,encoding='utf-8')
(Path(__file__).parent/'ui-report.json').write_text(json.dumps(dict(group=group,rect=rect,controller=controller,views=views,lines=lines,objective=objective,choice=choicecomp,objectCount=len(output)),indent=2))
print('Saved all dialogue canvases, choices, sentences, objective and car prompt below SeatingCanvas/PoliceEncounter.')
