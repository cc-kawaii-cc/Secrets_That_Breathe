using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using SecretsThatBreathe;

namespace UnityEngine {
 public class HeaderAttribute:Attribute { public HeaderAttribute(string s){} }
 public class TooltipAttribute:Attribute { public TooltipAttribute(string s){} }
 public class InspectorNameAttribute:Attribute {public InspectorNameAttribute(string s){}}
 public class MinAttribute:Attribute { public MinAttribute(float v){} }
 public class HideInInspector:Attribute {}
 public class GameObject { public string name="test"; public bool activeSelf=true; public Transform transform; public SceneManagement.Scene scene; public GameObject(){transform=new Transform(this);} public void SetActive(bool b){activeSelf=b;} }
 public class Transform { public GameObject gameObject; public Transform parent; public Vector3 position; public Transform(GameObject g){gameObject=g;} public Transform Find(string s)=>null; public Vector3 TransformPoint(Vector3 p)=>p; }
 public class MonoBehaviour { public GameObject gameObject=new GameObject(); public Transform transform=>gameObject.transform; public void StopAllCoroutines(){} public object StartCoroutine(IEnumerator e)=>e; }
 public struct Vector2 {public float x,y;public Vector2(float x,float y){this.x=x;this.y=y;} public float sqrMagnitude=>x*x+y*y;}
 public struct Vector3 {public float x,y,z;public Vector3(float x,float y,float z){this.x=x;this.y=y;this.z=z;} public static Vector3 operator -(Vector3 a,Vector3 b)=>new Vector3(a.x-b.x,a.y-b.y,a.z-b.z);}
 public static class Mathf {public static float Abs(float f)=>Math.Abs(f);}
 public static class Time {public static float timeScale=1;}
 public static class Application {public static bool isFocused=true;}
 public enum CursorLockMode {None,Locked}
 public static class Cursor {public static CursorLockMode lockState=CursorLockMode.Locked;public static bool visible;}
}
namespace UnityEngine.SceneManagement { public struct Scene {public UnityEngine.GameObject[] GetRootGameObjects()=>Array.Empty<UnityEngine.GameObject>();public static bool operator ==(Scene a,Scene b)=>true;public static bool operator !=(Scene a,Scene b)=>false;public override bool Equals(object o)=>o is Scene;public override int GetHashCode()=>0;} }
namespace UnityEngine.InputSystem {public class KeyControl{public bool wasPressedThisFrame;}public class Keyboard{public static Keyboard current;public KeyControl fKey=new KeyControl();}}
namespace UnityEngine.Events {public class UnityEvent{public void Invoke(){}}}
namespace UnityEngine.UI {public class ClickEvent {private Action action;public void AddListener(Action a){action+=a;}public void Invoke(){action?.Invoke();}}public class Button{public ClickEvent onClick=new ClickEvent();}}
namespace TMPro {public class TMP_Text {public string text;public UnityEngine.GameObject gameObject=new UnityEngine.GameObject();public UnityEngine.Transform transform=>gameObject.transform;public bool enabled=true;public int maxVisibleCharacters;public TMP_Text(string s){text=s;transform.parent=new UnityEngine.GameObject().transform;}}}
namespace StarterAssets {public class FirstPersonController:UnityEngine.MonoBehaviour{}}
namespace SecretsThatBreathe {
 public class DialogueCanvasView {public bool visible;public void Hide(){visible=false;}}
 public class FlowingDialogueSettings {public float secondsPerCharacter=.05f,completedLineHold=1f,scrollSpeed=18f;public object typingAudio;}
 internal class FlowingDialogue {private DialogueCanvasView view;private FlowingDialogueSettings settings;public FlowingDialogue(DialogueCanvasView v,FlowingDialogueSettings s){view=v;settings=s;Hide();}public IEnumerator Play(string s){view.visible=true;Harness.Lines.Add((s,false,settings.completedLineHold,settings.secondsPerCharacter));yield return null;}public IEnumerator ShowInstant(string s,float h){view.visible=true;Harness.Lines.Add((s,true,h,0));yield return null;}public void Hide(){view.Hide();}}
 public class AuntMoneyChoiceUI {public UnityEngine.UI.Button acceptButton=new UnityEngine.UI.Button(),refuseButton=new UnityEngine.UI.Button();public TMPro.TMP_Text acceptLabel=new TMPro.TMP_Text(""),refuseLabel=new TMPro.TMP_Text("");public bool shown;public void ShowChoices(){shown=true;}public void HideChoices(){shown=false;}}
 public class PorschePassengerRide:UnityEngine.MonoBehaviour {public bool HasExited;public UnityEngine.Transform exitPoint;public UnityEngine.Vector3 exitLocalPosition;public IEnumerator BoardParkedCar(bool b){yield break;}}
 public class PoliceJumpscareSequence {public void BeginReaction(bool b){} public void EndReaction(){} public IEnumerator FocusOn(UnityEngine.Transform t){if(t==null)Harness.Check(Harness.Current.khem.visible,"Completed Khem sentence disappeared during camera focus");yield return null;}public IEnumerator PushPlayerBack(){Harness.Check(Harness.Current.khem.visible,"Completed sentence disappeared during push reaction");yield return null;}}
}
class Harness {
 public static EveningPoliceDialogue Current;
 public static List<(string text,bool narration,float hold,float interval)> Lines=new List<(string,bool,float,float)>();
 public static void Check(bool valid,string reason){if(!valid)throw new Exception(reason);}
 static TMPro.TMP_Text T(string s)=>new TMPro.TMP_Text(s);
 static void RunBranch(int first,int second){
  Lines.Clear();var c=new EveningPoliceDialogue();Current=c;c.choices=new AuntMoneyChoiceUI();c.sunglassesMan=new UnityEngine.GameObject().transform;
  c.introduction=T("intro");c.lieReply=T("<color=#FF3333>(โกหก)</color> lie");c.lawyerReply=T("lawyer");c.radioReaction=T("(radio)");c.refusedReaction=T("refused");c.sunglassesReply=T("sunglasses");c.evidenceReply=T("evidence");c.threatReaction=T("(threat)");c.finalPoliceReply=T("final");
  typeof(EveningPoliceDialogue).GetMethod("Awake",BindingFlags.NonPublic|BindingFlags.Instance).Invoke(c,null);
  var selections=new Queue<int>(new[]{first,second});var stack=new Stack<IEnumerator>();stack.Push(c.Run(new PoliceJumpscareSequence(),new StarterAssets.FirstPersonController(),new PorschePassengerRide()));int steps=0,menus=0;
  while(stack.Count>0){Check(++steps<100,"Dialogue did not complete");var e=stack.Peek();if(!e.MoveNext()){stack.Pop();continue;}if(e.Current is IEnumerator nested){stack.Push(nested);continue;}if(c.choices.shown){Check(!c.police.visible&&!c.khem.visible&&!c.action.visible,"Dialogue overlaps choices");Check(selections.Count>0,"Unexpected extra menu");menus++;if(selections.Dequeue()==0)c.choices.acceptButton.onClick.Invoke();else c.choices.refuseButton.onClick.Invoke();}}
  Check(c.Completed&&menus==2&&selections.Count==0,"Choice branch did not finish");Check(Lines.Count==5,"Changed number of spoken/narrated lines");
  string[] expected={"intro",first==0?"lie":"lawyer",first==0?"(radio)":"refused",second==0?"sunglasses":"evidence",second==0?"(threat)":"final"};
  for(int i=0;i<5;i++){Check(Lines[i].text==expected[i],"Changed reply branch/order or leaked lie marker");Check(Lines[i].hold==(Lines[i].narration?3f:1f),"Incorrect completed-line hold: "+Lines[i].text);if(!Lines[i].narration)Check(Lines[i].interval==.05f,"Incorrect typing speed");}
  Check(!c.police.visible&&!c.khem.visible&&!c.action.visible&&!c.choices.shown,"Dialogue remains visible after completion");Console.WriteLine($"PASS branch {first+1}/{second+1}: 5 lines, two choices, spoken hold 1s, narration hold 3s; no blank camera transition or leftover UI.");
 }
 public static int Main(){try{for(int a=0;a<2;a++)for(int b=0;b<2;b++)RunBranch(a,b);Console.WriteLine("Controller coroutine tests use UI/audio/camera stubs; no Unity Play Mode or rendered frames were tested.");return 0;}catch(Exception e){Console.Error.WriteLine(e);return 1;}}
}
