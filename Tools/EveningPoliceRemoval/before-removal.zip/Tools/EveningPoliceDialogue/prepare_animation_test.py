"""Isolate actual animation switching from gameplay; no changes to source models."""
from pathlib import Path
import shutil,json
ROOT=Path(__file__).resolve().parents[2]
test=ROOT/'Tools/CompileChecks/PoliceAnimationRegressionUnity'
(test/'Packages').mkdir(parents=True,exist_ok=True)
(test/'Packages/manifest.json').write_text(json.dumps({'dependencies':{f'com.unity.modules.{m}':'1.0.0' for m in ['animation','physics','audio','jsonserialize']}}))
(test/'ProjectSettings').mkdir(exist_ok=True)
shutil.copyfile(ROOT/'ProjectSettings/ProjectVersion.txt',test/'ProjectSettings/ProjectVersion.txt')
characters=test/'Assets/SecretsThatBreathe/Characters'
characters.mkdir(parents=True,exist_ok=True)
shutil.copytree(ROOT/'Assets/SecretsThatBreathe/Characters/ThaiPolice',characters/'ThaiPolice',dirs_exist_ok=True)
shutil.copytree(ROOT/'Assets/SecretsThatBreathe/Characters/NavySuitVillain',characters/'NavySuitVillain',dirs_exist_ok=True)
idle=characters/'LowPolyMaleSlowWalk';idle.mkdir(exist_ok=True)
for name in ['LowPolyMale_IdleTalk.fbx','LowPolyMale_IdleTalk.fbx.meta','LowPolyMale_IdleTalk.controller','LowPolyMale_IdleTalk.controller.meta']:
    shutil.copyfile(ROOT/'Assets/SecretsThatBreathe/Characters/LowPolyMaleSlowWalk'/name,idle/name)
scripts=test/'Assets/Scripts';scripts.mkdir(exist_ok=True)
for name in ['PoliceJumpscareSequence.cs','PoliceJumpscareSequence.cs.meta','PoliceJumpscareRange.cs.meta','SuitEncounterLook.cs','SuitEncounterLook.cs.meta']:
    shutil.copyfile(ROOT/'Assets/SecretsThatBreathe/Scripts'/name,scripts/name)
(scripts/'PoliceJumpscareRange.cs').write_text('''using UnityEngine;
namespace SecretsThatBreathe { public class PoliceJumpscareRange : MonoBehaviour {
public PorschePassengerRide arrivalRide; public StarterAssets.FirstPersonController player;
public bool IsPlayerInRange => false;
} }''')
(scripts/'GameplayDependencies.cs').write_text('''using UnityEngine; using System.Collections;
namespace StarterAssets {
public class FirstPersonController : MonoBehaviour { public void ResetAfterTeleport(float pitch) {} }
public class FirstPersonFlashlight : MonoBehaviour { public void ForceOff() {} }
public class StarterAssetsInputs : MonoBehaviour { public Vector2 look, move; public bool jump, sprint; }
}
namespace SecretsThatBreathe {
public class PorschePassengerRide : MonoBehaviour { public bool HasExited; public float fieldOfView=65; public int TestingCheckpointVersion; }
public class EveningPoliceDialogue : MonoBehaviour {
public Transform sunglassesMan; public bool Completed;
public void ResetForTesting() {} public void EnableReturnToCar() {}
public IEnumerator Run(PoliceJumpscareSequence sequence, StarterAssets.FirstPersonController player, PorschePassengerRide ride) { yield break; }
}
}''')
editor=test/'Assets/Editor';editor.mkdir(exist_ok=True)
shutil.copyfile(ROOT/'Assets/SecretsThatBreathe/Scripts/Editor/PoliceConversationRegressionCheck.cs',editor/'PoliceConversationRegressionCheck.cs')
(editor/'RegressionEntry.cs').write_text('''using System.IO; using System.Reflection; using UnityEditor; using UnityEngine;
public static class RegressionEntry { public static void Run() {
var type=typeof(SecretsThatBreathe.Editor.PoliceConversationRegressionCheck);
type.GetMethod("RunRequested",BindingFlags.Static|BindingFlags.NonPublic).Invoke(null,null);
var report=Path.GetFullPath(Path.Combine(Application.dataPath,"../Tools/EveningPoliceDialogue/conversation-regression.txt"));
string result=File.Exists(report)?File.ReadAllText(report):"FAIL: report missing";
Debug.Log(result); EditorApplication.Exit(result.StartsWith("PASS:")?0:1);
} }''')
reports=test/'Tools/EveningPoliceDialogue';reports.mkdir(parents=True,exist_ok=True)
(reports/'check-conversation.request').write_text('Verify player Idle Talk and partner Standing Conversation loop independently.')
print('Prepared isolated Unity animation regression project.')
