from pathlib import Path
import json,re
ROOT=Path(__file__).resolve().parents[2]
s=(ROOT/'Assets/MainScenes/From_PM/MainScene_2_Evening.unity').read_text(encoding='utf-8-sig')
blocks={int(m[2]):m.group() for m in re.finditer(r'^--- !u!(\d+) &(-?\d+)[^\n]*\n.*?(?=^---|\Z)',s,re.M|re.S)}
report=json.loads((Path(__file__).parent/'ui-report.json').read_text())
new={i:b for i,b in blocks.items() if 732000000<=i<732001000}
for id,b in new.items():
    for ref in re.finditer(r'\{fileID: (-?\d+)([^}]*)}',b):
        target=int(ref[1])
        assert not target or 'guid:' in ref[2] or target in blocks,(id,target)
    if b.startswith('--- !u!224 '):
        current=id
        for _ in range(20):
            parent=int(re.search(r'm_Father: \{fileID: (\d+)',blocks[current])[1])
            assert parent,('UI outside SeatingCanvas',id)
            owner=int(re.search(r'm_GameObject: \{fileID: (\d+)',blocks[parent])[1])
            if 'm_Name: SeatingCanvas\n' in blocks[owner]: break
            current=parent
        else: raise AssertionError('UI hierarchy cycle')
lie=blocks[report['lines']['lieReply']]
assert '<color=#FF3333>' in lie and '</color>' in lie
choice=blocks[report['choice']]
for label in ['acceptLabel','refuseLabel']:
    id=int(re.search('  '+label+r': \{fileID: (\d+)',choice)[1])
    assert 'm_isRichText: 1' in blocks[id]
    assert 'm_fontColor: {r: 1, g: 1, b: 1, a: 1}' in blocks[id]
assert 'm_fontColor: {r: 0.8666667, g: 0.8666667, b: 0, a: 1}' in blocks[report['objective']['returnObjective']]
assert sum('m_OnClick:' in b for b in new.values())==2
assert all('m_Calls: []' in b[b.index('m_OnClick:'):] for b in new.values() if 'm_OnClick:' in b)
assert len(report['lines'])==9
for field in ['returnObjective','enterCarPrompt']:
    label=blocks[report['objective'][field]]
    go=int(re.search(r'm_GameObject: \{fileID: (\d+)',label)[1])
    rect=next(b for b in blocks.values() if b.startswith('--- !u!224 ') and f'm_GameObject: {{fileID: {go}}}\n' in b)
    panel_rect=int(re.search(r'm_Father: \{fileID: (\d+)',rect)[1])
    # Simulate showing the authored parent panel. All remaining ancestors must be active.
    for _ in range(20):
        parent=int(re.search(r'm_Father: \{fileID: (\d+)',blocks[panel_rect])[1])
        if not parent: break
        parent_go=int(re.search(r'm_GameObject: \{fileID: (\d+)',blocks[parent])[1])
        assert 'm_IsActive: 1' in blocks[parent_go],('Disabled prompt ancestor',field,parent_go)
        panel_rect=parent
for name,expected in [('KhemDialogue','{r: 0.25, g: 0.7, b: 1, a: 1}'),('PoliceDialogue','{r: 0.6754716, g: 0.22292897, b: 0.15166242, a: 1}')]:
    assert 'm_fontColor: '+expected in blocks[report['views'][name]['speaker']]
    assert 'm_fontColor: {r: 1, g: 1, b: 1, a: 1}' in blocks[report['views'][name]['sentence']]
print('Verified: all UI under SeatingCanvas, no dangling local references, 9 editable story lines, 2 clean choice buttons, red lie tag, yellow objective.')
