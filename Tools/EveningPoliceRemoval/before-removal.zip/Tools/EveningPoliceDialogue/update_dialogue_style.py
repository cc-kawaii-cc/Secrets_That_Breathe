from pathlib import Path
import re
ROOT=Path(__file__).resolve().parents[2]
p=ROOT/'Assets/MainScenes/From_PM/MainScene_2_Evening.unity'
s=p.read_text(encoding='utf-8-sig')
blocks={int(m[2]):m.group() for m in re.finditer(r'^--- !u!(\d+) &(-?\d+)[^\n]*\n.*?(?=^---|\Z)',s,re.M|re.S)}
guid=re.search(r'guid: (\w+)',(ROOT/'Assets/SecretsThatBreathe/Scripts/EveningPoliceDialogue.cs.meta').read_text())[1]
ui=next(b for b in blocks.values() if f'guid: {guid},' in b)
for view,color in [('khem',(.25,.7,1)),('police',(.6754716,.22292897,.15166242)),('action',(.6754716,.22292897,.15166242))]:
    refs=re.search(r'^  '+view+r':\n(.*?)(?=^  \w|\Z)',ui,re.M|re.S)[1]
    rgba=sum(int(v*255+.5)<<(8*i) for i,v in enumerate((*color,1)))
    for name in ('speaker','sentence'):
        id=int(re.search(r'    '+name+r': \{fileID: (\d+)',refs)[1])
        b=blocks[id]
        rgb='{r: %s, g: %s, b: %s, a: 1}'%color if name=='speaker' else '{r: 1, g: 1, b: 1, a: 1}'
        replacement=re.sub(r'^  (m_Color|m_fontColor): .*',lambda m:'  '+m[1]+': '+rgb,b,flags=re.M)
        replacement=re.sub(r'    rgba: \d+','    rgba: '+str(rgba if name=='speaker' else 4294967295),replacement)
        s=s.replace(b,replacement)
newui=ui
if '  dialogueStyleRevision:' in newui: newui=re.sub(r'  dialogueStyleRevision: .*','  dialogueStyleRevision: 3',newui)
else: newui+='  dialogueStyleRevision: 3\n'
s=s.replace(ui,newui)
p.write_text(s,encoding='utf-8')
print('Saved white sentences, Khem blue name, police brown name; choice colours unchanged.')
