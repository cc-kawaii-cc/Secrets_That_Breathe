using UnityEngine;

namespace SecretsThatBreathe
{
    [DisallowMultipleComponent]
    public sealed class SuitEncounterLook : MonoBehaviour
    {
        public float facingYawOffset;
        private Animator animator;
        private Transform[] bones;
        private Vector3[] neutralPositions, neutralScales;
        private Quaternion[] neutralRotations;
        private Quaternion originalRotation, turnFrom, turnTo, returnFrom, returnTo;
        private bool initialized, captured, wasEnabled;
        private float oldSpeed;
        private RuntimeAnimatorController originalController;

        private void Awake() => Initialize();
        private void Initialize()
        {
            if (initialized) return;
            originalRotation = transform.rotation;
            foreach (var candidate in GetComponentsInChildren<Animator>(true))
            {
                if (!candidate.gameObject.activeInHierarchy) continue;
                foreach (var renderer in candidate.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                    if (renderer.enabled && renderer.gameObject.activeInHierarchy) { animator = candidate; break; }
                if (animator != null) break;
            }
            if (animator != null)
            {
                bones = animator.GetComponentsInChildren<Transform>(true);
                neutralPositions = new Vector3[bones.Length];
                neutralScales = new Vector3[bones.Length];
                neutralRotations = new Quaternion[bones.Length];
                for (int i = 0; i < bones.Length; i++)
                {
                    neutralPositions[i] = bones[i].localPosition;
                    neutralScales[i] = bones[i].localScale;
                    neutralRotations[i] = bones[i].localRotation;
                }
            }
            initialized = true;
        }
        private Quaternion Facing(Vector3 point)
        {
            Vector3 direction = point-transform.position; direction.y=0f;
            return direction.sqrMagnitude > .001f
                ? Quaternion.LookRotation(direction, Vector3.up)*Quaternion.Euler(0f,facingYawOffset,0f) : transform.rotation;
        }
        public void BeginLookAt(Vector3 playerPosition)
        {
            Initialize();
            if (captured) return;
            captured = true;
            turnFrom = transform.rotation;
            turnTo = Facing(playerPosition);
            if (animator == null) return;
            wasEnabled = animator.enabled;
            oldSpeed = animator.speed;
            originalController = animator.runtimeAnimatorController;
            animator.enabled = false;
            // Restore the authored neutral standing pose, not a frozen mid-gesture frame.
            for (int i = 0; i < bones.Length; i++)
            {
                bones[i].SetLocalPositionAndRotation(neutralPositions[i], neutralRotations[i]);
                bones[i].localScale = neutralScales[i];
            }
        }
        public void TurnToPlayer(float progress)
        {
            if (captured) transform.rotation = Quaternion.Slerp(turnFrom,turnTo,Mathf.SmoothStep(0f,1f,Mathf.Clamp01(progress)));
        }
        public void BeginReturnToPolice(Transform police)
        {
            if (!captured) return;
            returnFrom = transform.rotation;
            returnTo = police != null ? Facing(police.position) : originalRotation;
        }
        public void TurnBack(float progress)
        {
            if (captured) transform.rotation = Quaternion.Slerp(returnFrom,returnTo,Mathf.SmoothStep(0f,1f,Mathf.Clamp01(progress)));
        }
        public void ResumeConversation()
        {
            if (!captured) return;
            captured = false;
            if (animator == null) return;
            animator.runtimeAnimatorController = originalController;
            animator.enabled = wasEnabled;
            animator.speed = oldSpeed;
            if (!wasEnabled || !animator.gameObject.activeInHierarchy || originalController == null) return;
            Vector3 position = animator.transform.localPosition, scale = animator.transform.localScale;
            Quaternion rotation = animator.transform.localRotation;
            animator.Rebind(); animator.Update(0f);
            int state = Animator.StringToHash("Base Layer.Standing Conversation");
            if (!animator.HasState(0,state)) state = animator.GetCurrentAnimatorStateInfo(0).fullPathHash;
            animator.Play(state,0,0f); animator.Update(0f);
            animator.transform.SetLocalPositionAndRotation(position,rotation);
            animator.transform.localScale = scale;
        }
        public void ResetForTesting()
        {
            if (!initialized) return;
            transform.rotation = originalRotation;
            ResumeConversation();
        }
    }
}
