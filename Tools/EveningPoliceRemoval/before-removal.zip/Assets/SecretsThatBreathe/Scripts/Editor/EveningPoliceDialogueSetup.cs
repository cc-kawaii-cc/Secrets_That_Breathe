using System;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SecretsThatBreathe.Editor
{
    [InitializeOnLoad]
    public static class EveningPoliceDialogueSetup
    {
        private static bool installing;
        private const string ScenePath = "Assets/MainScenes/From_PM/MainScene_2_Evening.unity";
        static EveningPoliceDialogueSetup()
        {
            EditorApplication.delayCall += Install;
            EditorSceneManager.sceneOpened += (scene, mode) => EditorApplication.delayCall += Install;
            EditorApplication.playModeStateChanged += state =>
            {
                if (state == PlayModeStateChange.EnteredEditMode) EditorApplication.delayCall += Install;
                if (state == PlayModeStateChange.ExitingEditMode) Install();
            };
        }
        [MenuItem("Tools/Secrets That Breathe/Evening/Repair Police Dialogue UI")]
        public static void Install()
        {
            if (installing || EditorApplication.isPlaying) return;
            if (EditorApplication.isUpdating || EditorApplication.isCompiling)
            { EditorApplication.delayCall += Install; return; }
            var scene = SceneManager.GetSceneByPath(ScenePath);
            if (!scene.IsValid() || !scene.isLoaded) return;
            var canvas = scene.GetRootGameObjects().FirstOrDefault(go => go.name == "SeatingCanvas");
            if (canvas == null) return;
            var existing = canvas.transform.Find("PoliceEncounter");
            if (existing != null)
            {
                ApplyDialogueStyle(existing.GetComponent<EveningPoliceDialogue>(), scene);
                return;
            }
            installing = true;
            Scene preview = default;
            try
            {
                preview = EditorSceneManager.OpenPreviewScene(ScenePath);
                var template = preview.GetRootGameObjects().First(go => go.name == "SeatingCanvas").transform.Find("PoliceEncounter");
                if (template == null) throw new InvalidOperationException("PoliceEncounter is missing from the saved scene.");
                var copy = UnityEngine.Object.Instantiate(template.gameObject, canvas.transform, false);
                copy.name = "PoliceEncounter";
                Undo.RegisterCreatedObjectUndo(copy, "Add saved police dialogue UI");
                EditorSceneManager.MarkSceneDirty(scene);
                string folder = Path.GetFullPath(Path.Combine(Application.dataPath, "../Tools/EveningPoliceDialogue"));
                Directory.CreateDirectory(folder);
                File.WriteAllText(Path.Combine(folder, "editor-installation.txt"), "PoliceEncounter installed under the open scene's SeatingCanvas. Save the scene to retain live scene edits.");
            }
            finally
            {
                if (preview.IsValid()) EditorSceneManager.ClosePreviewScene(preview);
                installing = false;
            }
        }
        private static void ApplyDialogueStyle(EveningPoliceDialogue ui, Scene scene)
        {
            if (ui == null) return;
            var serialized = new SerializedObject(ui);
            var revision = serialized.FindProperty("dialogueStyleRevision");
            if (revision == null || revision.intValue >= 4) return;
            Color blue = new Color(.25f, .7f, 1f);
            Color brown = new Color(.6754716f, .22292897f, .15166242f);
            foreach (var entry in new[] { (ui.khem, blue), (ui.police, brown), (ui.action, brown) })
                foreach (var text in new[] { entry.Item1.speaker, entry.Item1.sentence })
                    if (text != null)
                    {
                        Undo.RecordObject(text, "Restore speaker dialogue colours");
                        text.color = text == entry.Item1.speaker ? entry.Item2 : Color.white;
                        EditorUtility.SetDirty(text);
                    }
            if (ui.returnObjective != null && ui.returnObjective.transform.parent is RectTransform panel)
            {
                Undo.RecordObject(panel, "Match Lawyer Room yellow objective position");
                panel.anchorMin = panel.anchorMax = new Vector2(.5f, .16f);
                panel.pivot = new Vector2(.5f, .5f);
                panel.anchoredPosition = new Vector2(0f, -100f);
                panel.sizeDelta = new Vector2(1400f, 150f);
            }
            revision.intValue = 4;
            serialized.ApplyModifiedProperties();
            EditorSceneManager.MarkSceneDirty(scene);
        }
    }
}
