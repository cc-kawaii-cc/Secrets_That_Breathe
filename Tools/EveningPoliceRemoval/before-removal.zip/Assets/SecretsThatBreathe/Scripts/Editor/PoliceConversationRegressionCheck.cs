using System;
using System.IO;
using System.Linq;
using System.Reflection;
using UnityEditor;
using UnityEditor.SceneManagement;
using UnityEngine;
using UnityEngine.SceneManagement;

namespace SecretsThatBreathe.Editor
{
    [InitializeOnLoad]
    public static class PoliceConversationRegressionCheck
    {
        private static string Folder => Path.GetFullPath(Path.Combine(Application.dataPath, "../Tools/EveningPoliceDialogue"));
        static PoliceConversationRegressionCheck()
        {
            EditorApplication.delayCall += RunRequested;
            EditorApplication.playModeStateChanged += state =>
            {
                if (state == PlayModeStateChange.EnteredEditMode) EditorApplication.delayCall += RunRequested;
            };
        }
        private static void RunRequested()
        {
            string request = Path.Combine(Folder, "check-conversation.request");
            if (!File.Exists(request) || EditorApplication.isPlayingOrWillChangePlaymode) return;
            if (EditorApplication.isCompiling || EditorApplication.isUpdating)
            { EditorApplication.delayCall += RunRequested; return; }
            var preview = EditorSceneManager.NewPreviewScene();
            try
            {
                var prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/SecretsThatBreathe/Characters/ThaiPolice/IdleTalk/ThaiPolice_IdleTalk.prefab");
                var instance = (GameObject)PrefabUtility.InstantiatePrefab(prefab, preview);
                var sequence = instance.GetComponents<MonoBehaviour>().First(c => c != null && c.GetType().Name == "PoliceJumpscareSequence");
                var restart = sequence.GetType().GetMethod("StartTalkingIdle", BindingFlags.Instance | BindingFlags.NonPublic);
                var resume = sequence.GetType().GetMethod("ResumePartnerConversation", BindingFlags.Instance | BindingFlags.NonPublic);
                int playerMoving = 0, partnerMoving = 0;
                SizeSample playerSize = null, partnerSize = null;
                for (int cycle = 0; cycle < 2; cycle++)
                {
                    restart.Invoke(sequence, null);
                    var playerAnimator = Visible(instance);
                    playerSize = MeasureSize(playerAnimator, instance.transform, "player Idle Talk");
                    playerMoving = ValidateLoop(playerAnimator, "Idle Talk");
                    ValidateCameraAndArm(sequence, playerAnimator);
                    foreach (var bone in playerAnimator.GetComponentsInChildren<Transform>())
                        if (bone.name == "UpperArm.R" || bone.name == "Forearm.L") bone.localRotation *= Quaternion.Euler(40f, 20f, 10f);
                    resume.Invoke(sequence, null);
                    var partnerAnimator = Visible(instance);
                    partnerSize = MeasureSize(partnerAnimator, instance.transform, "partner Standing Conversation");
                    if (playerAnimator == partnerAnimator) throw new Exception("Both conversations use the same rig.");
                    partnerMoving = ValidateLoop(partnerAnimator, "Standing Conversation");
                }
                File.WriteAllText(Path.Combine(Folder, "conversation-regression.txt"),
                    "PASS: fixed camera aim ignores head motion; arm release blends gradually; two animation round trips loop correctly. Moving bones: " + playerMoving + "/" + partnerMoving);
                File.WriteAllText(Path.Combine(Folder, "police-size-comparison.json"), JsonUtility.ToJson(new SizeReport { samples = new[] { playerSize, partnerSize } }, true));
                if (Mathf.Abs(playerSize.legLength-partnerSize.legLength) > .001f || Mathf.Abs(playerSize.torsoLength-partnerSize.torsoLength) > .001f)
                    throw new Exception("Police changes skeletal size when switching conversations.");
                ValidateSuitEncounter(preview, instance.transform);
                File.Delete(request);
            }
            catch (Exception error)
            {
                File.WriteAllText(Path.Combine(Folder, "conversation-regression.txt"), "FAIL: " + error);
                File.Delete(request);
                Debug.LogException(error);
            }
            finally { EditorSceneManager.ClosePreviewScene(preview); }
        }
        private static Animator Visible(GameObject instance) => instance.GetComponentsInChildren<Animator>(true).Single(a => a.gameObject.activeInHierarchy
            && a.GetComponentsInChildren<SkinnedMeshRenderer>(true).Any(r => r.enabled && r.gameObject.activeInHierarchy));
        private static void ValidateSuitEncounter(Scene preview, Transform police)
        {
            var prefab = AssetDatabase.LoadAssetAtPath<GameObject>("Assets/SecretsThatBreathe/Characters/NavySuitVillain/NavySuitVillain.prefab");
            var suit = (GameObject)PrefabUtility.InstantiatePrefab(prefab, preview);
            suit.transform.position = police.position + Vector3.right*2f;
            var behaviour = suit.GetComponents<MonoBehaviour>().First(c => c != null && c.GetType().Name == "SuitEncounterLook");
            var type = behaviour.GetType();
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            type.GetMethod("Initialize",flags).Invoke(behaviour,null);
            var animator = Visible(suit);
            var controller = animator.runtimeAnimatorController;
            animator.Rebind(); animator.Update(0f);
            ValidateLoop(animator,"Standing Conversation");
            Vector3 viewer = police.position + Vector3.back*3f;
            type.GetMethod("BeginLookAt").Invoke(behaviour,new object[]{viewer});
            for (int i=0;i<=12;i++) type.GetMethod("TurnToPlayer").Invoke(behaviour,new object[]{i/12f});
            if (animator.enabled) throw new Exception("Suit animation is still enabled during police dialogue.");
            if (Vector3.Dot(suit.transform.forward,(viewer-suit.transform.position).normalized)<.999f) throw new Exception("Suit does not face the player.");
            var bones = (Transform[])type.GetField("bones",flags).GetValue(behaviour);
            var neutral = (Quaternion[])type.GetField("neutralRotations",flags).GetValue(behaviour);
            for (int i=0;i<bones.Length;i++)
                if (Quaternion.Angle(bones[i].localRotation,neutral[i])>.01f) throw new Exception("Suit did not return to neutral standing pose.");
            type.GetMethod("BeginReturnToPolice").Invoke(behaviour,new object[]{police});
            for (int i=0;i<=12;i++) type.GetMethod("TurnBack").Invoke(behaviour,new object[]{i/12f});
            type.GetMethod("ResumeConversation").Invoke(behaviour,null);
            if (!animator.enabled || animator.runtimeAnimatorController!=controller) throw new Exception("Suit conversation was not restored.");
            if (Vector3.Dot(suit.transform.forward,(police.position-suit.transform.position).normalized)<.999f) throw new Exception("Suit does not face the police after dialogue.");
            int moving = ValidateLoop(animator,"Standing Conversation");
            File.WriteAllText(Path.Combine(Folder,"suit-encounter-regression.txt"),
                "PASS: suit turns to player, disables animation in neutral standing pose, turns back to police and resumes looping conversation. Moving bones after return: "+moving);
        }
        [Serializable] private class SizeReport { public SizeSample[] samples; }
        [Serializable] private class SizeSample { public string state; public float legLength, torsoLength; public Vector3 meshSize, meshMin, modelScale; }
        private static SizeSample MeasureSize(Animator animator, Transform actor, string state)
        {
            var bones = animator.GetComponentsInChildren<Transform>();
            Func<string, Vector3> point = name => actor.InverseTransformPoint(bones.First(t => t.name == name).position);
            Func<string, string, float> length = (a, b) => Vector3.Distance(point(a), point(b));
            bool hasBounds = false;
            Bounds bounds = default;
            foreach (var renderer in animator.GetComponentsInChildren<SkinnedMeshRenderer>())
            {
                if (!renderer.enabled) continue;
                var mesh = renderer.sharedMesh;
                var vertices = mesh.vertices;
                var weights = mesh.boneWeights;
                var bindposes = mesh.bindposes;
                var matrices = renderer.bones.Select((bone, index) => bone.localToWorldMatrix * bindposes[index]).ToArray();
                for (int i = 0; i < vertices.Length; i++)
                {
                    var w = weights[i];
                    Vector3 vertex = vertices[i];
                    // Explicit skinning avoids applying FBX unit-conversion scale twice.
                    Vector3 world = matrices[w.boneIndex0].MultiplyPoint3x4(vertex)*w.weight0
                        + matrices[w.boneIndex1].MultiplyPoint3x4(vertex)*w.weight1
                        + matrices[w.boneIndex2].MultiplyPoint3x4(vertex)*w.weight2
                        + matrices[w.boneIndex3].MultiplyPoint3x4(vertex)*w.weight3;
                    Vector3 p = actor.InverseTransformPoint(world);
                    if (!hasBounds) { bounds = new Bounds(p, Vector3.zero); hasBounds = true; }
                    else bounds.Encapsulate(p);
                }
            }
            return new SizeSample { state = state, meshSize = bounds.size, meshMin = bounds.min, modelScale = animator.transform.lossyScale,
                legLength = length("UpperLeg.L", "LowerLeg.L") + length("LowerLeg.L", "Foot.L"),
                torsoLength = length("Hips", "Spine") + length("Spine", "Chest") + length("Chest", "Neck") + length("Neck", "Head") };
        }
        private static void ValidateCameraAndArm(MonoBehaviour sequence, Animator animator)
        {
            const BindingFlags flags = BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic;
            var type = sequence.GetType();
            var head = animator.GetComponentsInChildren<Transform>().First(t => t.name == "Head");
            type.GetField("cameraPosition", flags).SetValue(sequence, sequence.transform.position + new Vector3(0f, 1.7f, -3f));
            type.GetField("lockedPoliceLookPoint", flags).SetValue(sequence, head.position);
            type.GetField("faceTarget", flags).SetValue(sequence, head);
            var look = type.GetMethod("LookAtFace", flags);
            Quaternion before = (Quaternion)look.Invoke(sequence, null);
            head.position += Vector3.right * .5f;
            Quaternion after = (Quaternion)look.Invoke(sequence, null);
            if (Quaternion.Angle(before, after) > .001f) throw new Exception("Camera still tracks the animated head.");
            type.GetMethod("BeginReaction", flags).Invoke(sequence, new object[] { true });
            type.GetField("reactionWeight", flags).SetValue(sequence, 1f);
            type.GetMethod("EndReaction", flags).Invoke(sequence, null);
            float duration = (float)type.GetField("armLowerSeconds", flags).GetValue(sequence);
            float previous = 1f;
            foreach (float progress in new[] { 0f, .25f, .5f, .75f, 1f })
            {
                animator.Update(0f);
                type.GetField("reactionReleaseStarted", flags).SetValue(sequence, Time.time - duration*progress);
                type.GetMethod("ApplyReactionPose", flags).Invoke(sequence, null);
                float weight = (float)type.GetField("reactionWeight", flags).GetValue(sequence);
                if (weight > previous + .001f || (progress > 0f && progress < 1f && (weight <= 0f || weight >= 1f)))
                    throw new Exception("Arm release does not blend gradually.");
                previous = weight;
            }
            if (previous > .001f) throw new Exception("Arm release never reaches idle.");
        }
        private static int ValidateLoop(Animator animator, string stateName)
        {
            var clips = animator.GetCurrentAnimatorClipInfo(0);
            if (clips.Length == 0 || !clips[0].clip.isLooping) throw new Exception("No looping clip is playing.");
            float duration = clips[0].clip.length;
            for (int i = 0; i < 110; i++) animator.Update(duration / 100f);
            var state = animator.GetCurrentAnimatorStateInfo(0);
            if (!state.loop || state.shortNameHash != Animator.StringToHash(stateName)) throw new Exception("Incorrect conversation state: " + stateName);
            var bones = animator.GetComponentsInChildren<Transform>();
            var rotations = bones.Select(t => t.localRotation).ToArray();
            animator.Update(duration * .2f);
            int moving = bones.Where((bone, index) => Quaternion.Angle(rotations[index], bone.localRotation) > .01f).Count();
            if (moving == 0) throw new Exception("Police skeleton stops moving after the clip loops.");
            return moving;
        }
    }
}
