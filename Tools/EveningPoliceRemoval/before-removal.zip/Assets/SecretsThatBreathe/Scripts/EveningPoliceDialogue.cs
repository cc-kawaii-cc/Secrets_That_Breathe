using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.Events;

namespace SecretsThatBreathe
{
    public sealed class EveningPoliceDialogue : MonoBehaviour
    {
        [Header("Saved dialogue canvases copied from Lawyer Room")]
        public DialogueCanvasView police = new DialogueCanvasView();
        public DialogueCanvasView khem = new DialogueCanvasView();
        public DialogueCanvasView action = new DialogueCanvasView();
        [Tooltip("Spoken lines use the same typing, completed-line hold and scrolling as Lawyer Room, including the final police reply.")]
        public FlowingDialogueSettings presentation = new FlowingDialogueSettings();
        [Header("Full-text narration timing")]
        [Min(0f)] public float narrationHoldSeconds = 3f;
        [Tooltip("Only the final full-text action/narration uses this hold. A spoken final reply uses Presentation > Completed Line Hold.")]
        [InspectorName("Final Narration Hold Seconds")]
        [Min(0f)] public float finalReactionHoldSeconds = 3f;
        public AuntMoneyChoiceUI choices;
        [Header("ChoiceDialogue / ChoiceTexts (button wording only)")]
        [Tooltip("Saved choice text sources, independent from the spoken lines below.")]
        public TMP_Text choiceLie, choiceLawyer, choiceSunglasses, choiceEvidence;
        [HideInInspector] public int dialogueStyleRevision;
        [Header("SpokenDialogue / SpokenLines (typewriter dialogue only)")]
        public TMP_Text introduction, lieReply, lawyerReply, radioReaction, refusedReaction;
        public TMP_Text sunglassesReply, evidenceReply, threatReaction, finalPoliceReply;
        [Header("Return to the car")]
        public TMP_Text returnObjective, enterCarPrompt;
        [Min(.5f)] public float boardingDistance = 2f;
        public Transform sunglassesMan;
        [Header("Scene transition after boarding and fading to black")]
        public UnityEvent onReadyToChangeScene = new UnityEvent();
        public bool ReadyToChangeScene { get; private set; }
        public bool Completed { get; private set; }
        private PorschePassengerRide ride;
        private StarterAssets.FirstPersonController player;
        private FlowingDialogue flowing;
        private int selected = -1;
        private bool returning, boarding;
        private GameObject testingHints;
        private bool restoreTestingHints;
        private static EveningPoliceDialogue current;
        public static bool BlocksFlashlightToggle(UnityEngine.SceneManagement.Scene scene)
            => current != null && current.gameObject.scene == scene && (current.boarding || current.NearDoor());

        private void Awake()
        {
            current = this;
            HideDialogue();
            ShowPrompt(returnObjective, false);
            ShowPrompt(enterCarPrompt, false);
            choices.acceptButton.onClick.AddListener(ChooseFirst);
            choices.refuseButton.onClick.AddListener(ChooseSecond);
        }
        private void ChooseFirst() { if (selected < 0) selected = 0; }
        private void ChooseSecond() { if (selected < 0) selected = 1; }
        public IEnumerator Run(PoliceJumpscareSequence sequence, StarterAssets.FirstPersonController walking, PorschePassengerRide car)
        {
            player = walking; ride = car;
            if (sunglassesMan == null)
                foreach (var root in gameObject.scene.GetRootGameObjects())
                    if (root.name == "NavySuitVillain") sunglassesMan = root.transform;
            yield return Say(police, introduction);
            yield return Pick(choiceLie, choiceLawyer);
            int first = selected;
            yield return Say(khem, first == 0 ? lieReply : lawyerReply);
            if (first == 0) sequence.BeginReaction(true);
            yield return Say(first == 0 ? action : police, first == 0 ? radioReaction : refusedReaction);
            sequence.EndReaction();
            yield return Pick(choiceSunglasses, choiceEvidence);
            int second = selected;
            if (second == 0 && sunglassesMan != null) yield return sequence.FocusOn(sunglassesMan);
            yield return Say(khem, second == 0 ? sunglassesReply : evidenceReply);
            if (second == 0) yield return sequence.FocusOn(null);
            if (second == 0) yield return sequence.PushPlayerBack();
            yield return Say(second == 0 ? action : police, second == 0 ? threatReaction : finalPoliceReply, finalReactionHoldSeconds);
            sequence.EndReaction();
            HideDialogue();
            Completed = true;
        }
        private IEnumerator Say(DialogueCanvasView view, TMP_Text line, float narrationHold = -1f)
        {
            flowing?.Hide();
            flowing = new FlowingDialogue(view, presentation);
            string sentence = line.text;
            // FlowingDialogue already holds a completed sentence for the Lawyer Room duration.
            bool narration = view == action || (sentence.TrimStart().StartsWith("(") && sentence.TrimEnd().EndsWith(")"));
            if (narration) yield return flowing.ShowInstant(sentence, narrationHold < 0f ? narrationHoldSeconds : narrationHold);
            else yield return flowing.Play(sentence);
            // Like Lawyer Room, keep the completed sentence until the next line or
            // choice actually begins. Camera reactions must not introduce blank gaps.
        }
        private IEnumerator Pick(TMP_Text first, TMP_Text second)
        {
            HideDialogue();
            choices.acceptLabel.text = first.text;
            choices.refuseLabel.text = second.text;
            selected = -1;
            choices.ShowChoices();
            while (selected < 0) yield return null;
            choices.HideChoices();
        }
        public void EnableReturnToCar()
        {
            returning = true;
            ShowPrompt(returnObjective, true);
        }
        private static GameObject PromptPanel(TMP_Text label) => label != null ? label.transform.parent.gameObject : null;
        private static void ShowPrompt(TMP_Text label, bool show)
        {
            var panel = PromptPanel(label);
            if (panel == null) return;
            if (show)
            {
                label.gameObject.SetActive(true);
                label.enabled = true;
                label.maxVisibleCharacters = int.MaxValue;
            }
            panel.SetActive(show);
        }
        private bool NearDoor()
        {
            if (!returning || boarding || ride == null || player == null || !ride.HasExited) return false;
            Vector3 door = ride.exitPoint != null ? ride.exitPoint.position : ride.transform.TransformPoint(ride.exitLocalPosition);
            Vector3 delta = player.transform.position - door;
            return Mathf.Abs(delta.y) < 2f && new Vector2(delta.x, delta.z).sqrMagnitude <= boardingDistance * boardingDistance;
        }
        private void Update()
        {
            bool near = NearDoor();
            var panel = PromptPanel(enterCarPrompt);
            if (panel != null && panel.activeSelf != near) ShowPrompt(enterCarPrompt, near);
            if (near && Time.timeScale > 0f && Application.isFocused && Cursor.lockState == CursorLockMode.Locked
                && Keyboard.current != null && Keyboard.current.fKey.wasPressedThisFrame) StartCoroutine(Board());
        }
        private IEnumerator Board()
        {
            boarding = true;
            ShowPrompt(enterCarPrompt, false);
            ShowPrompt(returnObjective, false);
            var hints = transform.parent != null ? transform.parent.Find("TestingShortcutHints") : null;
            if (hints != null)
            {
                testingHints = hints.gameObject;
                restoreTestingHints = testingHints.activeSelf;
                testingHints.SetActive(false);
            }
            yield return ride.BoardParkedCar(true);
            if (ride.HasExited)
            {
                boarding = false;
                returning = true;
                ShowPrompt(returnObjective, true);
                RestoreTestingHints();
                yield break;
            }
            returning = boarding = false;
            ReadyToChangeScene = true;
            onReadyToChangeScene.Invoke();
        }
        public void ResetForTesting()
        {
            StopAllCoroutines();
            HideDialogue();
            Completed = returning = boarding = false;
            ReadyToChangeScene = false;
            RestoreTestingHints();
            ShowPrompt(returnObjective, false);
            ShowPrompt(enterCarPrompt, false);
        }
        private void RestoreTestingHints()
        {
            if (testingHints != null && restoreTestingHints) testingHints.SetActive(true);
            restoreTestingHints = false;
        }
        private void HideDialogue()
        {
            flowing?.Hide();
            police.Hide(); khem.Hide(); action.Hide();
            if (choices != null) choices.HideChoices();
        }
        private void OnDisable() { StopAllCoroutines(); HideDialogue(); }
        private void OnDestroy() { if (current == this) current = null; }
    }
}
