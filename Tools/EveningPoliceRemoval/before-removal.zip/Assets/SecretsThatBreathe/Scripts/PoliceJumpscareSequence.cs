using System.Collections;
using StarterAssets;
using UnityEngine;

namespace SecretsThatBreathe
{
    [DefaultExecutionOrder(30000)]
    [RequireComponent(typeof(PoliceJumpscareRange))]
    [DisallowMultipleComponent]
    public sealed class PoliceJumpscareSequence : MonoBehaviour
    {
        public PoliceJumpscareRange proximity;
        [Tooltip("Sampled once when the scare starts; the camera does not track this bone afterwards.")]
        public Transform faceTarget;
        public Vector3 fallbackFaceLocalPosition = new Vector3(0f, 1.62f, 0f);
        [Header("Lawyer Room turn and zoom timing")]
        [Min(.05f)] public float snapDuration = .4f;
        [Tooltip("Zero starts the zoom and sound immediately with the camera turn.")]
        [Range(0f, 1f)] public float zoomStartTurnFraction = 0f;
        [Min(.05f)] public float zoomDuration = .6f;
        [Range(10f, 90f)] public float scareFieldOfView = 30f;
        [Min(0f)] public float closeUpHoldSeconds = .8f;
        [Min(.05f)] public float returnDuration = 1f;
        [Header("Police facing and talking idle")]
        [Min(.05f)] public float policeTurnSeconds = .4f;
        public float facingYawOffset;
        public RuntimeAnimatorController talkingIdle;
        public string talkingStateName = "Idle Talk";
        public Transform playerTalkModel;
        public Transform partnerTalkModel;
        [Tooltip("Seconds to blend the raised radio/reaction arm back into the talking idle.")]
        [Min(.05f)] public float armLowerSeconds = 1f;
        [Header("Sound — adjust Volume on this saved AudioSource")]
        public AudioSource scareAudio;
        public EveningPoliceDialogue dialogue;
        public SuitEncounterLook sunglassesLook;
        public bool HasTriggered { get; private set; }
        private bool captured;
        private Camera view;
        private FirstPersonController player;
        private Behaviour brain;
        private bool oldBrainEnabled, oldPlayerEnabled;
        private Vector3 cameraPosition;
        private Quaternion initialCameraRotation, initialPoliceRotation;
        private float originalFov;
        private int checkpointVersion;
        private bool dialogueActive, changingFocus;
        private Transform focusSubject;
        private FirstPersonFlashlight[] flashlights;
        private bool[] flashlightStates;
        private Transform upperR, forearmR, handR, upperL, forearmL, handL;
        private int reaction;
        private float reactionStarted;
        private bool releasingReaction;
        private float reactionWeight, reactionReleaseStarted, reactionReleaseWeight;
        private Vector3 lockedPoliceLookPoint, lockedSubjectLookPoint;

        private void Awake()
        {
            if (proximity == null) proximity = GetComponent<PoliceJumpscareRange>();
            initialPoliceRotation = transform.rotation;
        }
        private void LateUpdate()
        {
            if (proximity == null) return;
            // F1 returns to the parked passenger checkpoint; allow another test.
            if (proximity.arrivalRide != null && checkpointVersion != proximity.arrivalRide.TestingCheckpointVersion)
            {
                checkpointVersion = proximity.arrivalRide.TestingCheckpointVersion;
                StopAllCoroutines();
                dialogueActive = changingFocus = false;
                focusSubject = null;
                reaction = 0;
                if (dialogue != null) dialogue.ResetForTesting();
                if (sunglassesLook != null) sunglassesLook.ResetForTesting();
                Restore(true);
                if (scareAudio != null) scareAudio.Stop();
                transform.rotation = initialPoliceRotation;
                ResumePartnerConversation();
                HasTriggered = false;
            }
            if (captured && dialogueActive && !changingFocus) SetCamera(LookAtFace(), view.fieldOfView);
            if (captured && reaction != 0) ApplyReactionPose();
            if (HasTriggered || !proximity.IsPlayerInRange) return;
            player = proximity.player;
            if (player == null) return;
            view = null;
            foreach (var candidate in FindObjectsByType<Camera>(FindObjectsSortMode.None))
                if (candidate.gameObject.scene == gameObject.scene && candidate.CompareTag("MainCamera"))
                { view = candidate; break; }
            if (view == null) return;
            HasTriggered = true;
            StartCoroutine(PlayScare());
        }

        private void StartTalkingIdle()
        {
            faceTarget = null;
            SwitchModel(playerTalkModel, partnerTalkModel);
            var animators = playerTalkModel != null ? playerTalkModel.GetComponentsInChildren<Animator>(true) : GetComponentsInChildren<Animator>(true);
            foreach (var animator in animators)
            {
                if (!animator.gameObject.activeInHierarchy) continue;
                bool visible = false;
                foreach (var renderer in animator.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                    if (renderer.enabled && renderer.gameObject.activeInHierarchy) { visible = true; break; }
                if (!visible) continue;
                animator.enabled = true;
                animator.speed = 1f;
                animator.applyRootMotion = false;
                animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                if (animator.runtimeAnimatorController == null && talkingIdle != null)
                    animator.runtimeAnimatorController = talkingIdle;
                if (animator.runtimeAnimatorController == null) continue;
                // Clear temporary arm poses and restart the actual talking state's loop.
                Vector3 localPosition = animator.transform.localPosition, localScale = animator.transform.localScale;
                Quaternion localRotation = animator.transform.localRotation;
                animator.Rebind();
                animator.Update(0f);
                int state = Animator.StringToHash("Base Layer." + talkingStateName);
                if (!animator.HasState(0, state)) state = animator.GetCurrentAnimatorStateInfo(0).fullPathHash;
                animator.Play(state, 0, 0f);
                animator.Update(0f);
                animator.transform.SetLocalPositionAndRotation(localPosition, localRotation);
                animator.transform.localScale = localScale;
                upperR = Bone(animator, "UpperArm.R"); forearmR = Bone(animator, "Forearm.R"); handR = Bone(animator, "Hand.R");
                upperL = Bone(animator, "UpperArm.L"); forearmL = Bone(animator, "Forearm.L"); handL = Bone(animator, "Hand.L");
                if (faceTarget == null)
                    foreach (var bone in animator.GetComponentsInChildren<Transform>())
                        if (bone.name == "Head" || bone.name.EndsWith(":Head")) { faceTarget = bone; break; }
            }
        }
        private static void SwitchModel(Transform show, Transform hide)
        {
            if (hide != null) hide.gameObject.SetActive(false);
            if (show == null) return;
            show.gameObject.SetActive(true);
            foreach (var renderer in show.GetComponentsInChildren<SkinnedMeshRenderer>(true)) renderer.enabled = true;
        }
        private void ResumePartnerConversation()
        {
            reaction = 0;
            if (partnerTalkModel == null) return;
            SwitchModel(partnerTalkModel, playerTalkModel);
            faceTarget = null;
            foreach (var animator in partnerTalkModel.GetComponentsInChildren<Animator>(true))
            {
                if (!animator.gameObject.activeInHierarchy || animator.runtimeAnimatorController == null) continue;
                animator.enabled = true;
                animator.speed = 1f;
                animator.applyRootMotion = false;
                animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
                Vector3 position = animator.transform.localPosition, scale = animator.transform.localScale;
                Quaternion rotation = animator.transform.localRotation;
                animator.Rebind();
                animator.Update(0f);
                int state = Animator.StringToHash("Base Layer.Standing Conversation");
                if (!animator.HasState(0, state)) state = animator.GetCurrentAnimatorStateInfo(0).fullPathHash;
                animator.Play(state, 0, 0f);
                animator.Update(0f);
                animator.transform.SetLocalPositionAndRotation(position, rotation);
                animator.transform.localScale = scale;
                foreach (var bone in animator.GetComponentsInChildren<Transform>())
                    if (bone.name == "Head" || bone.name.EndsWith(":Head")) { faceTarget = bone; break; }
            }
        }
        private static Transform Bone(Animator animator, string name)
        {
            foreach (var bone in animator.GetComponentsInChildren<Transform>()) if (bone.name == name) return bone;
            return null;
        }
        public void BeginReaction(bool radio)
        {
            reaction = radio ? 1 : 2;
            reactionStarted = Time.time;
            releasingReaction = false;
            reactionWeight = 0f;
        }
        public void EndReaction()
        {
            if (reaction == 0 || releasingReaction) return;
            releasingReaction = true;
            reactionReleaseStarted = Time.time;
            reactionReleaseWeight = reactionWeight;
        }
        private void ApplyReactionPose()
        {
            float weight;
            if (releasingReaction)
            {
                float progress = Mathf.Clamp01((Time.time - reactionReleaseStarted)/Mathf.Max(.05f, armLowerSeconds));
                weight = reactionReleaseWeight * (1f - Mathf.SmoothStep(0f, 1f, progress));
                if (progress >= 1f) { reaction = 0; reactionWeight = 0f; return; }
            }
            else weight = Mathf.SmoothStep(0f, 1f, (Time.time - reactionStarted)/.25f);
            reactionWeight = weight;
            Vector3 rightTarget = transform.TransformPoint(reaction == 1 ? new Vector3(.18f, 1.45f, .04f) : new Vector3(.22f, .86f, -.03f));
            AimArm(upperR, forearmR, handR, rightTarget, transform.right, weight);
            if (reaction == 2 && player != null)
                AimArm(upperL, forearmL, handL, player.transform.position + Vector3.up * 1.2f, -transform.right, weight);
        }
        private static void AimArm(Transform upper, Transform forearm, Transform hand, Vector3 target, Vector3 bend, float weight)
        {
            if (upper == null || forearm == null || hand == null) return;
            float a = Vector3.Distance(upper.position, forearm.position), b = Vector3.Distance(forearm.position, hand.position);
            Vector3 delta = target - upper.position;
            float distance = Mathf.Clamp(delta.magnitude, .01f, Mathf.Max(.02f, a+b-.005f));
            Vector3 direction = delta.normalized;
            Vector3 outward = Vector3.ProjectOnPlane(bend, direction).normalized;
            float along = (a*a-b*b+distance*distance)/(2f*distance);
            Vector3 elbow = upper.position + direction*along + outward*Mathf.Sqrt(Mathf.Max(0f, a*a-along*along));
            upper.rotation = Quaternion.Slerp(upper.rotation, Quaternion.FromToRotation(forearm.position-upper.position, elbow-upper.position)*upper.rotation, weight);
            forearm.rotation = Quaternion.Slerp(forearm.rotation, Quaternion.FromToRotation(hand.position-forearm.position, target-forearm.position)*forearm.rotation, weight);
        }
        public IEnumerator PushPlayerBack()
        {
            BeginReaction(false);
            yield return new WaitForSeconds(.3f);
            var controller = player.GetComponent<CharacterController>();
            Vector3 away = player.transform.position-transform.position; away.y=0f; away.Normalize();
            for (float t=0f; t<.3f;)
            {
                float step = Mathf.Min(Time.deltaTime, .3f-t); t+=step;
                Vector3 before = player.transform.position;
                if (controller != null && controller.enabled) controller.Move(away*(.3f*step/.3f));
                cameraPosition += player.transform.position-before;
                SetCamera(LookAtFace(), view.fieldOfView);
                yield return null;
            }
        }
        private Quaternion LookAtFace()
        {
            Vector3 target = focusSubject != null ? lockedSubjectLookPoint : lockedPoliceLookPoint;
            Vector3 delta = target - cameraPosition;
            return delta.sqrMagnitude > .00001f ? Quaternion.LookRotation(delta, Vector3.up) : initialCameraRotation;
        }
        public IEnumerator FocusOn(Transform subject)
        {
            focusSubject = subject;
            if (subject != null) lockedSubjectLookPoint = subject.position + Vector3.up * 1.65f;
            changingFocus = true;
            Quaternion from = view.transform.rotation;
            for (float t = 0f; t < .35f; t += Time.deltaTime)
            { SetCamera(Quaternion.Slerp(from, LookAtFace(), Mathf.SmoothStep(0f, 1f, t/.35f)), view.fieldOfView); yield return null; }
            changingFocus = false;
        }
        private void SetCamera(Quaternion rotation, float fov)
        {
            view.transform.SetPositionAndRotation(cameraPosition, rotation);
            view.fieldOfView = fov;
        }
        private IEnumerator PlayScare()
        {
            cameraPosition = view.transform.position;
            initialCameraRotation = view.transform.rotation;
            originalFov = view.fieldOfView;
            oldPlayerEnabled = player.enabled;
            player.enabled = false;
            brain = null;
            foreach (var behaviour in view.GetComponents<Behaviour>())
                if (behaviour.GetType().Name == "CinemachineBrain") { brain = behaviour; break; }
            if (brain != null) { oldBrainEnabled = brain.enabled; brain.enabled = false; }
            captured = true;
            flashlights = player.transform.root.GetComponentsInChildren<FirstPersonFlashlight>(true);
            flashlightStates = new bool[flashlights.Length];
            for (int i = 0; i < flashlights.Length; i++)
            {
                flashlightStates[i] = flashlights[i].enabled;
                flashlights[i].ForceOff();
                flashlights[i].enabled = false;
            }
            if (dialogue == null)
                foreach (var candidate in FindObjectsByType<EveningPoliceDialogue>(FindObjectsInactive.Include, FindObjectsSortMode.None))
                    if (candidate.gameObject.scene == gameObject.scene) { dialogue = candidate; break; }
            StartTalkingIdle();
            // Capture a stationary aim point once; IdleTalk head bob and rig swaps
            // must not move the dialogue camera.
            lockedPoliceLookPoint = faceTarget != null ? faceTarget.position : transform.TransformPoint(fallbackFaceLocalPosition);
            if (sunglassesLook == null)
                foreach (var candidate in FindObjectsByType<SuitEncounterLook>(FindObjectsSortMode.None))
                    if (candidate.gameObject.scene == gameObject.scene) { sunglassesLook = candidate; break; }
            if (sunglassesLook != null) sunglassesLook.BeginLookAt(cameraPosition);
            Quaternion fromPolice = transform.rotation;
            Vector3 direction = cameraPosition - transform.position;
            direction.y = 0f;
            Quaternion toPolice = direction.sqrMagnitude > .00001f
                ? Quaternion.LookRotation(direction, Vector3.up) * Quaternion.Euler(0f, facingYawOffset, 0f) : fromPolice;
            float delay = snapDuration * zoomStartTurnFraction;
            float duration = Mathf.Max(policeTurnSeconds, snapDuration, delay + zoomDuration);
            bool played = false;
            for (float t = 0f; t < duration; t += Time.deltaTime)
            {
                transform.rotation = Quaternion.Slerp(fromPolice, toPolice, Mathf.SmoothStep(0f, 1f, t / Mathf.Max(.05f, policeTurnSeconds)));
                if (sunglassesLook != null) sunglassesLook.TurnToPlayer(t / Mathf.Max(.05f, policeTurnSeconds));
                if (!played && t >= delay)
                { if (scareAudio != null && scareAudio.clip != null) scareAudio.PlayOneShot(scareAudio.clip); played = true; }
                SetCamera(Quaternion.Slerp(initialCameraRotation, LookAtFace(), Mathf.SmoothStep(0f, 1f, t / Mathf.Max(.05f, snapDuration))),
                    Mathf.Lerp(originalFov, scareFieldOfView, Mathf.SmoothStep(0f, 1f, Mathf.Clamp01((t-delay)/Mathf.Max(.05f, zoomDuration)))));
                yield return null;
            }
            transform.rotation = toPolice;
            if (sunglassesLook != null) sunglassesLook.TurnToPlayer(1f);
            for (float t = 0f; t < closeUpHoldSeconds; t += Time.deltaTime)
            { SetCamera(LookAtFace(), scareFieldOfView); yield return null; }
            if (dialogue != null)
            {
                dialogueActive = true;
                yield return dialogue.Run(this, player, proximity.arrivalRide);
                dialogueActive = false;
            }
            focusSubject = null;
            Quaternion returnPolice = initialPoliceRotation;
            if (dialogue != null && dialogue.sunglassesMan != null)
            {
                Vector3 back = dialogue.sunglassesMan.position - transform.position; back.y = 0f;
                if (back.sqrMagnitude > .001f) returnPolice = Quaternion.LookRotation(back) * Quaternion.Euler(0f, facingYawOffset, 0f);
            }
            Quaternion spokenRotation = transform.rotation;
            if (sunglassesLook != null) sunglassesLook.BeginReturnToPolice(transform);
            for (float t = 0f; t < returnDuration; t += Time.deltaTime)
            {
                transform.rotation = Quaternion.Slerp(spokenRotation, returnPolice, Mathf.SmoothStep(0f, 1f, t/Mathf.Max(.05f, returnDuration)));
                if (sunglassesLook != null) sunglassesLook.TurnBack(t/Mathf.Max(.05f,returnDuration));
                SetCamera(LookAtFace(), Mathf.Lerp(scareFieldOfView, originalFov, Mathf.SmoothStep(0f, 1f, t/Mathf.Max(.05f, returnDuration)))); yield return null;
            }
            transform.rotation = returnPolice;
            // Use the partner conversation rig only after turning back to the suited man.
            ResumePartnerConversation();
            if (sunglassesLook != null) { sunglassesLook.TurnBack(1f); sunglassesLook.ResumeConversation(); }
            SetCamera(LookAtFace(), originalFov);
            Restore(false);
            if (dialogue != null && dialogue.Completed) dialogue.EnableReturnToCar();
        }
        private void Restore(bool cancelled)
        {
            if (!captured) return;
            captured = false;
            reaction = 0;
            bool returningToCar = proximity != null && proximity.arrivalRide != null && !proximity.arrivalRide.HasExited;
            if (view != null)
            {
                view.fieldOfView = returningToCar ? proximity.arrivalRide.fieldOfView : originalFov;
                if (cancelled && !returningToCar) view.transform.SetPositionAndRotation(cameraPosition, initialCameraRotation);
                if (player != null && !returningToCar)
                {
                    Vector3 angles = view.transform.eulerAngles;
                    player.transform.rotation = Quaternion.Euler(0f, angles.y, 0f);
                    player.ResetAfterTeleport(Mathf.DeltaAngle(0f, angles.x));
                    var inputs = player.GetComponent<StarterAssetsInputs>();
                    if (inputs != null) { inputs.look = inputs.move = Vector2.zero; inputs.jump = inputs.sprint = false; }
                }
            }
            if (player != null) player.enabled = oldPlayerEnabled && !returningToCar;
            if (brain != null) brain.enabled = oldBrainEnabled && !returningToCar;
            if (flashlights != null)
                for (int i = 0; i < flashlights.Length; i++)
                    if (flashlights[i] != null) flashlights[i].enabled = flashlightStates[i] && !returningToCar;
        }
        private void OnDisable()
        {
            bool interrupted = captured;
            StopAllCoroutines(); Restore(true);
            if (interrupted && sunglassesLook != null) sunglassesLook.ResetForTesting();
        }
    }
}
