using System.Collections;
using UnityEngine;

namespace SecretsThatBreathe
{
    public sealed partial class PorschePassengerRide
    {
        public IEnumerator BoardParkedCar(bool holdBlackForSceneChange = false)
        {
            if (!hasExited || exitInProgress || !EnsureExitUI()) yield break;
            exitInProgress = true;
            var walking = playerRoot.GetComponentInChildren<StarterAssets.FirstPersonController>(true);
            if (walking != null) walking.enabled = false;
            SetRidingFlashlightState(false);
            ClearWalkingInput();
            if (openDoorClip != null) doorAudio.PlayOneShot(openDoorClip);
            yield return FadeExit(1f, exitFadeOutSeconds);
            hasExited = passengerDetached = false;
            enabled = true;
            HasArrived = true;
            IsMoving = false;
            CurrentSpeed = 0f;
            UpdatePassengerPose();
            Physics.SyncTransforms();
            if (exteriorAmbience != null) exteriorAmbience.StopExteriorForTesting();
            yield return new WaitForSeconds(Mathf.Max(exitBlackHoldSeconds,
                openDoorClip != null ? openDoorClip.length - exitFadeOutSeconds + .15f : 0f));
            if (closeDoorClip != null) doorAudio.PlayOneShot(closeDoorClip);
            yield return new WaitForSeconds(.15f);
            if (holdBlackForSceneChange)
            {
                exitBlack.alpha = 1f;
                exitBlack.blocksRaycasts = true;
                ClearWalkingInput();
                // Keep exitInProgress true: walking, passenger look and exit input
                // stay locked while a scene loader takes over the black screen.
                yield break;
            }
            yield return FadeExit(0f, exitFadeInSeconds);
            stoppedSeconds = 0f;
            ClearWalkingInput();
            exitInProgress = false;
        }
    }
}
